#include <msgpack/adaptor/define.hpp>

int main() {}
